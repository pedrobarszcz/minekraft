# MobVoice — Forge 1.20.1

Mod para Minecraft 1.20.1 (Forge 47.2.0 / Java 17) que combina conversa com criaturas e personalização local de vozes.

## Recursos

- Conversa por texto com o mob na mira usando `/falar <mensagem>`.
- Conversa por microfone segurando **V** (usa serviço de transcrição configurado pelo jogador).
- Perfil individual por criatura: personalidade, história, memória e afinidade com jogadores.
- Comandos de comportamento e relacionamento já presentes no sistema de IA.
- Item **Gravador de Voz**, disponível na aba Ferramentas e Utilidades e fabricável.
- Clique com o botão direito em um mob segurando o Gravador para abrir o estúdio de voz.
- Grave e personalize seis categorias: ambiente, dano, morte, passos, ataque e alerta (quando o mob/pacote de sons emitir eventos compatíveis).
- Gravações independentes para criaturas adultas e filhotes.
- Prévia e exclusão de cada gravação.
- Quando existe uma gravação correspondente, o cliente substitui o som original localmente.
- Sem gravação personalizada, o Minecraft mantém o som original.

## Como usar o gravador

1. Fabrique o **Gravador de Voz** (cobre, ferro e redstone) ou pegue-o no criativo.
2. Clique com o botão direito em uma criatura segurando o item.
3. Selecione Ambiente, Dano, Morte ou Passos.
4. Pressione **Gravar**, fale e pressione **Parar e salvar**. A gravação também para automaticamente no limite configurado.
5. Use **Ouvir prévia** para conferir ou **Excluir** para apagar a gravação selecionada.

Os arquivos ficam em `.minecraft/config/mobvoice/recordings/`. Eles permanecem no computador e não são enviados para serviços de IA. O recurso de substituição de áudio é local ao cliente; outros jogadores só ouvirão suas gravações se também tiverem os mesmos arquivos.

## Personalidade e comportamento

Cada criatura recebe um perfil próprio baseado em seu identificador: nome, personalidade, peculiaridade, história e objetivo. Ao conversar, o mob considera o horário, sua vida, a distância do jogador, o item segurado e o histórico de diálogo. O humor pode mudar conforme a conversa. A afinidade é individual para cada jogador e influencia se a criatura aceita seguir, esperar, proteger ou oferecer pequenos presentes. Algumas criaturas também podem iniciar comentários espontâneos quando o cérebro autônomo está ativado.

O sistema oferece conversa por microfone e por texto, além de memória resumida para manter o contexto sem guardar indefinidamente todo o histórico. As gravações de voz são separadas por tipo de criatura e por fase adulta/filhote; quando não há gravação específica para filhote, o mod tenta usar a gravação adulta correspondente.

## Configuração

Na primeira execução, o mod cria `.minecraft/config/mobvoice.json`.

- `replaceRecordedSounds`: liga/desliga a substituição local dos sons personalizados.
- `maxRecordingSeconds`: limite de duração de cada gravação (3 a 60 segundos).
- `apiKey`, `model`, `endpoint`: configuração opcional da conversa com IA.
- `sttApiKey`, `sttEndpoint`, `sttModel`, `sttLanguage`: configuração opcional de transcrição de voz.

As chaves de API são opcionais para o gravador de sons; são necessárias apenas para os recursos de IA/transcrição que as utilizam. Não compartilhe seu arquivo de configuração, pois ele pode conter chaves privadas.

## Requisitos

- Minecraft Java 1.20.1
- Minecraft Forge 47.2.0 ou outra versão Forge 47 compatível
- Java 17
- Microfone para gravar vozes

## Compilar

No Windows, instale o JDK 17 e execute `COMPILAR_NO_WINDOWS.bat`. O arquivo compilado será gerado em `build/libs/`.

> Observação técnica: a substituição de WAV é reproduzida pelo dispositivo de áudio local do cliente, com atenuação simples por distância; não usa o mixer espacial 3D do Minecraft. O código-fonte deve ser compilado e testado no Forge antes de distribuir o JAR.
