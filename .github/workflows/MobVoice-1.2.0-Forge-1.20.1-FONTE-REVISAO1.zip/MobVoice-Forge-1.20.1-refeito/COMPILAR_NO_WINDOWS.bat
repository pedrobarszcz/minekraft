@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ================================================
echo   MobVoice - Minecraft 1.20.1 Forge 47.2.0
echo ================================================
echo.

where java >nul 2>nul
if errorlevel 1 (
  echo ERRO: Java nao encontrado no PATH.
  echo Instale um JDK 17 e configure JAVA_HOME e PATH.
  pause
  exit /b 1
)

where javac >nul 2>nul
if errorlevel 1 (
  echo ERRO: compilador javac nao encontrado. Voce provavelmente instalou apenas o Java Runtime.
  echo Instale o JDK 17 completo, nao apenas o JRE.
  pause
  exit /b 1
)

rem FINDSTR recebe uma expressao simples; nao usar aspas escapadas com barra invertida no CMD.
java -version 2>&1 | findstr /C:"17." >nul
if errorlevel 1 (
  echo ERRO: este projeto exige JDK 17.
  echo Versao encontrada:
  java -version
  echo.
  echo Se houver varias versoes instaladas, coloque a pasta bin do JDK 17 no inicio do PATH.
  pause
  exit /b 1
)

javac -version 2>&1 | findstr /C:"17." >nul
if errorlevel 1 (
  echo ERRO: javac nao e da versao 17. Instale ou selecione o JDK 17 completo.
  javac -version
  pause
  exit /b 1
)

echo JDK 17 detectado corretamente.
set "TOOLS=%LOCALAPPDATA%\MobVoiceBuildTools"
set "GRADLE_HOME=%TOOLS%\gradle-8.1.1"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist "%TOOLS%" mkdir "%TOOLS%"
  echo Baixando Gradle 8.1.1. Isso requer internet...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.1.1-bin.zip' -OutFile '%TOOLS%\gradle-8.1.1-bin.zip'"
  if errorlevel 1 (
    echo ERRO: nao foi possivel baixar o Gradle. Verifique a conexao e tente novamente.
    pause
    exit /b 1
  )
  echo Extraindo Gradle...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%TOOLS%\gradle-8.1.1-bin.zip' '%TOOLS%'"
  if errorlevel 1 (
    echo ERRO: nao foi possivel extrair o Gradle.
    pause
    exit /b 1
  )
)

echo.
echo Compilando com ForgeGradle. Na primeira execucao, as dependencias serao baixadas.
call "%GRADLE_HOME%\bin\gradle.bat" --no-daemon clean build
if errorlevel 1 (
  echo.
  echo FALHA NA COMPILACAO. Copie o erro completo acima para diagnostico.
  pause
  exit /b 1
)

echo.
echo JAR GERADO EM:
echo %CD%\build\libs\mobvoice-forge-1.20.1-1.2.0.jar
echo Copie esse arquivo para %%appdata%%\.minecraft\mods e inicie Forge 1.20.1.
echo.
pause
