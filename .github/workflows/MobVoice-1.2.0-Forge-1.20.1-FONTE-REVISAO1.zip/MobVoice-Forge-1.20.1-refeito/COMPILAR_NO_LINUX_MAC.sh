#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "Java não encontrado. Instale o JDK 17."; exit 1
fi
JAVA_VERSION=$(java -version 2>&1 | head -n 1)
echo "$JAVA_VERSION"
if [[ "$JAVA_VERSION" != *'17.'* ]]; then
  echo "Este projeto exige JDK 17."; exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle não encontrado. Instale Gradle 8.1.1 ou superior e tente novamente."; exit 1
fi
gradle --no-daemon clean build
echo "JAR gerado em build/libs/"
