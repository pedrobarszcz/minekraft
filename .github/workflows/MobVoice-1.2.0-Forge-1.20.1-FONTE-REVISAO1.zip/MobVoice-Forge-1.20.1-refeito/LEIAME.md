# MobVoice — versão expandida

Projeto Forge para Minecraft 1.20.1. Esta edição adiciona um sistema de gravação e substituição de sons inspirado na ideia de mods em que o jogador grava vozes próprias para criaturas, além do sistema de conversa por IA já existente.

## O que há no projeto

- Item Gravador de Voz, com ícone, nome em português/inglês, receita e entrada na aba Ferramentas e Utilidades.
- Tela de gravação aberta ao clicar com o botão direito em uma criatura com o item.
- Categorias Ambiente, Dano, Morte e Passos.
- Gravações WAV individuais por tipo de entidade e por idade (adulto/filhote).
- Botões para gravar, parar/salvar, ouvir prévia e excluir.
- Limite de gravação configurável.
- Substituição local de sons correspondentes; se não existir WAV, o som original permanece.
- Conversa por texto e microfone, memória, personalidade e afinidade com mobs.

## Local das gravações

`.minecraft/config/mobvoice/recordings/`

Os WAVs são separados pelo identificador da criatura, idade e categoria. As gravações ficam no computador do jogador. O áudio gravado para personalização não é enviado à API de IA.

## Instalação e compilação

1. Use Minecraft 1.20.1, Forge 47.2.0 e Java 17.
2. Execute `COMPILAR_NO_WINDOWS.bat` em um Windows com acesso à internet para baixar Gradle e dependências.
3. Copie o JAR gerado em `build/libs/` para `.minecraft/mods`.

O ambiente em que este projeto foi editado não dispõe das dependências Gradle/Forge necessárias para validar a compilação. Portanto, esta entrega é o projeto-fonte expandido, não um JAR de mod já testado.

## Nota sobre áudio

O áudio customizado é tocado localmente pelo cliente e usa atenuação simples por distância. Não é uma substituição 3D perfeita do mixer interno do Minecraft. Em multiplayer, cada jogador precisa ter as mesmas gravações para ouvir os mesmos sons personalizados.


## Mecânicas sociais adicionadas (1.2.0)
- Peça a um Villager para localizar uma vila: custo de 3 esmeraldas.
- Peça a um Piglin para localizar um bastião: custo de 5 lingotes de ouro.
- A orientação informa coordenadas aproximadas e direção.
- Insultos/desafios reconhecidos provocam monstros e golens.
- Espadas, arcos/bestas e machados são identificados no contexto enviado à IA para respostas diferentes.
- A tecla V permanece em Push-to-Talk: segure para gravar e solte para enviar.

Observação: as provocações são detectadas por uma lista de expressões em português; criaturas passivas sem capacidade de combate não ganham comportamento de ataque. As respostas de personalidade dependem de uma chave de API válida.
