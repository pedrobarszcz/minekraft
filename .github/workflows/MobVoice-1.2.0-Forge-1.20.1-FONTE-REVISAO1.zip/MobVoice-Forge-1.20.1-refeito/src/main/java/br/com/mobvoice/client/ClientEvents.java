package br.com.mobvoice.client;

import br.com.mobvoice.MobVoice;
import br.com.mobvoice.ModItems;
import br.com.mobvoice.Net;
import br.com.mobvoice.TalkPacket;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.concurrent.CompletableFuture;

@Mod.EventBusSubscriber(modid = MobVoice.MOD_ID, value = Dist.CLIENT)
public class ClientEvents {
    private static final VoiceRecorder RECORDER = new VoiceRecorder();
    private static int targetId = -1;
    private static boolean warned = false;

    /** Mob que esta na mira (alcance de 8 blocos). */
    private static Mob findTarget(Minecraft mc) {
        Entity cam = mc.getCameraEntity();
        if (cam == null) return null;
        double reach = 8.0;
        Vec3 eye = cam.getEyePosition(1f);
        Vec3 look = cam.getViewVector(1f);
        Vec3 end = eye.add(look.scale(reach));
        AABB box = cam.getBoundingBox().expandTowards(look.scale(reach)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(cam, eye, end, box,
                e -> e instanceof Mob && !e.isSpectator() && e.isPickable(), reach * reach);
        return hit != null ? (Mob) hit.getEntity() : null;
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        boolean down = ClientModEvents.TALK_KEY.isDown() && mc.screen == null;
        if (!down) warned = false;

        if (down && !RECORDER.isRecording()) {
            Mob t = findTarget(mc);
            if (t == null) {
                if (!warned) {
                    mc.player.displayClientMessage(Component.literal("Olhe para um mob para falar com ele."), true);
                    warned = true;
                }
                return;
            }
            targetId = t.getId();
            if (RECORDER.start()) {
                mc.player.displayClientMessage(Component.literal("Gravando... fale com " + t.getName().getString()), true);
            } else if (!warned) {
                mc.gui.getChat().addMessage(Component.literal("[MobVoice] Não foi possível acessar o microfone. Verifique a permissão de microfone do Windows; você também pode usar /falar <mensagem>."));
                warned = true;
            }
        } else if (!down && RECORDER.isRecording()) {
            byte[] audio = RECORDER.stop();
            int id = targetId;
            if (audio.length < 12800) { // menos de 0,4 s
                mc.player.displayClientMessage(Component.literal("Fala muito curta."), true);
                return;
            }
            mc.player.displayClientMessage(Component.literal("Processando..."), true);
            CompletableFuture.supplyAsync(() -> SpeechToText.transcribe(audio)).whenComplete((text, err) ->
                    mc.execute(() -> {
                        if (mc.player == null) return;
                        if (err != null) {
                            Throwable c = err.getCause() != null ? err.getCause() : err;
                            mc.gui.getChat().addMessage(Component.literal("[MobVoice] Falha ao transcrever: " + c.getMessage()));
                            return;
                        }
                        if (text == null || text.isBlank()) {
                            mc.player.displayClientMessage(Component.literal("Não entendi o que você disse."), true);
                            return;
                        }
                        mc.gui.getChat().addMessage(Component.literal("Você: " + text));
                        Net.CHANNEL.sendToServer(new TalkPacket(id, text));
                    }));
        }
    }


    /** Abre o estúdio de gravação ao usar o gravador em uma criatura. */
    @SubscribeEvent
    public static void onMobInteract(PlayerInteractEvent.EntityInteract e) {
        if (e.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        if (!e.getItemStack().is(ModItems.VOICE_RECORDER.get())) return;
        if (!(e.getTarget() instanceof Mob mob)) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !e.getEntity().getUUID().equals(mc.player.getUUID())) return;
        ResourceLocation type = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType());
        if (type == null) return;
        boolean baby = mob instanceof AgeableMob ageable && ageable.isBaby();
        mc.setScreen(new MobRecorderScreen(type, mob.getName().getString(), baby));
        e.setCanceled(true);
    }

    /** Troca localmente sons de ambiente, dano, morte e passos quando há WAV personalizado. */
    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (!br.com.mobvoice.AiConfig.get().replaceRecordedSounds || mc.level == null || e.getSound() == null) return;
        String soundPath = e.getSound().getLocation().getPath();
        MobSoundLibrary.SoundKind kind = null;
        for (MobSoundLibrary.SoundKind candidate : MobSoundLibrary.SoundKind.values()) {
            if (soundPath.endsWith("." + candidate.id)) { kind = candidate; break; }
        }
        // Alguns pacotes de recursos usam "angry" como som de alerta/ameaça.
        if (kind == null && (soundPath.endsWith(".scream") || soundPath.endsWith(".growl"))) {
            kind = MobSoundLibrary.SoundKind.ANGRY;
        }
        if (kind == null || !soundPath.startsWith("entity.")) return;
        final MobSoundLibrary.SoundKind selected = kind;
        double x = e.getSound().getX();
        double y = e.getSound().getY();
        double z = e.getSound().getZ();
        net.minecraft.world.phys.AABB area = new net.minecraft.world.phys.AABB(x - 2.5, y - 2.5, z - 2.5, x + 2.5, y + 2.5, z + 2.5);
        Mob source = mc.level.getEntitiesOfClass(Mob.class, area, mob -> {
            ResourceLocation key = net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(mob.getType());
            return key != null && soundPath.startsWith("entity." + key.getPath() + ".");
        }).stream().min(java.util.Comparator.comparingDouble(mob -> mob.distanceToSqr(x, y, z))).orElse(null);
        if (source != null && MobSoundLibrary.replace(source, selected, e.getSound().getVolume(), x, z)) {
            e.setSound(null);
        }
    }

    /** /falar <texto>: conversa por texto com o mob na mira (alternativa ao microfone). */
    @SubscribeEvent
    public static void onRegisterCommands(RegisterClientCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("falar")
                .then(Commands.argument("texto", StringArgumentType.greedyString()).executes(ctx -> {
                    Minecraft mc = Minecraft.getInstance();
                    String text = StringArgumentType.getString(ctx, "texto");
                    Mob t = findTarget(mc);
                    if (t == null) {
                        mc.gui.getChat().addMessage(Component.literal("[MobVoice] Olhe para um mob para falar com ele."));
                        return 0;
                    }
                    mc.gui.getChat().addMessage(Component.literal("Você: " + text));
                    Net.CHANNEL.sendToServer(new TalkPacket(t.getId(), text));
                    return 1;
                })));
    }
}
