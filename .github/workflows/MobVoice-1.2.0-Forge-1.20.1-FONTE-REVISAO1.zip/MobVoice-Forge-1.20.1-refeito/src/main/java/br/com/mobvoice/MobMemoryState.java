package br.com.mobvoice;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Salva a memoria dos mobs junto com o mundo (data/mobvoice_memory.dat). */
public class MobMemoryState extends SavedData {
    private final Map<UUID, MobData> data = new HashMap<>();

    public static MobMemoryState get(MinecraftServer server) {
        return server.overworld().getDataStorage()
                .computeIfAbsent(MobMemoryState::load, MobMemoryState::new, "mobvoice_memory");
    }

    public boolean has(UUID id) { return data.containsKey(id); }

    public MobData peek(UUID id) { return data.get(id); }

    public MobData getOrCreate(Mob mob) {
        MobData d = data.get(mob.getUUID());
        if (d == null) {
            d = MobProfileFactory.create(mob);
            data.put(mob.getUUID(), d);
            setDirty();
        }
        return d;
    }

    public void remove(UUID id) {
        if (data.remove(id) != null) setDirty();
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag mobs = new ListTag();
        for (Map.Entry<UUID, MobData> e : data.entrySet()) {
            MobData d = e.getValue();
            CompoundTag c = new CompoundTag();
            c.putUUID("id", e.getKey());
            c.putString("name", d.name);
            c.putString("type", d.type);
            c.putString("personality", d.personality);
            c.putString("backstory", d.backstory);
            c.putString("summary", d.summary);
            c.putString("mood", d.mood);

            ListTag hist = new ListTag();
            for (AiClient.Msg m : d.history) {
                CompoundTag h = new CompoundTag();
                h.putString("r", m.role());
                h.putString("t", m.content());
                hist.add(h);
            }
            c.put("history", hist);

            ListTag aff = new ListTag();
            for (Map.Entry<UUID, Integer> a : d.affinity.entrySet()) {
                CompoundTag t = new CompoundTag();
                t.putUUID("p", a.getKey());
                t.putInt("a", a.getValue());
                aff.add(t);
            }
            c.put("affinity", aff);
            mobs.add(c);
        }
        tag.put("mobs", mobs);
        return tag;
    }

    public static MobMemoryState load(CompoundTag tag) {
        MobMemoryState s = new MobMemoryState();
        ListTag mobs = tag.getList("mobs", Tag.TAG_COMPOUND);
        for (int i = 0; i < mobs.size(); i++) {
            CompoundTag c = mobs.getCompound(i);
            MobData d = new MobData();
            d.name = c.getString("name");
            d.type = c.getString("type");
            d.personality = c.getString("personality");
            d.backstory = c.getString("backstory");
            d.summary = c.getString("summary");
            d.mood = c.getString("mood");
            ListTag hist = c.getList("history", Tag.TAG_COMPOUND);
            for (int j = 0; j < hist.size(); j++) {
                CompoundTag h = hist.getCompound(j);
                d.history.add(new AiClient.Msg(h.getString("r"), h.getString("t")));
            }
            ListTag aff = c.getList("affinity", Tag.TAG_COMPOUND);
            for (int j = 0; j < aff.size(); j++) {
                CompoundTag t = aff.getCompound(j);
                d.affinity.put(t.getUUID("p"), t.getInt("a"));
            }
            s.data.put(c.getUUID("id"), d);
        }
        return s;
    }
}
