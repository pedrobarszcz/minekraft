package br.com.mobvoice;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingChangeTargetEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

@Mod.EventBusSubscriber(modid = MobVoice.MOD_ID)
public class ServerEvents {

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.overworld() == null) return;
        int t = server.getTickCount();
        if (t % 5 == 0) MobBrain.tickCommands(server);
        if (t % 20 == 0) MobBrain.tickBrain(server);
    }

    /** Mob morreu: apaga a memoria dele. */
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (!(e.getEntity() instanceof Mob mob) || mob.level().isClientSide) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.overworld() == null) return;
        MobMemoryState.get(server).remove(mob.getUUID());
        MobBrain.forget(mob.getUUID());
    }

    /** Mobs que sao amigos (afinidade >= 10) nao atacam o jogador. */
    @SubscribeEvent
    public static void onChangeTarget(LivingChangeTargetEvent e) {
        if (!(e.getEntity() instanceof Mob mob) || mob.level().isClientSide) return;
        if (!(e.getNewTarget() instanceof ServerPlayer p)) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null || server.overworld() == null) return;
        MobData d = MobMemoryState.get(server).peek(mob.getUUID());
        if (d != null && d.getAffinity(p.getUUID()) >= MobBrain.FRIEND) {
            e.setNewTarget(null);
        }
    }

    @SubscribeEvent
    public static void onStopping(ServerStoppingEvent e) {
        MobBrain.clear();
    }
}
