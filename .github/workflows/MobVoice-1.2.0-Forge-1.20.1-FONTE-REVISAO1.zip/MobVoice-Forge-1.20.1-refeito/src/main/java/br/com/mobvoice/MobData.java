package br.com.mobvoice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Tudo que um mob "é" e "lembra". */
public class MobData {
    public String name;
    public String type;
    public String personality;
    public String backstory;
    public String summary = "";
    public String mood = "neutro";
    public final List<AiClient.Msg> history = new ArrayList<>();
    /** Afinidade (-100..100) com cada jogador. Quanto maior, mais ele obedece. */
    public final Map<UUID, Integer> affinity = new HashMap<>();

    public transient boolean summarizing;

    public int getAffinity(UUID player) { return affinity.getOrDefault(player, 0); }

    public int addAffinity(UUID player, int delta) {
        int v = Math.max(-100, Math.min(100, getAffinity(player) + delta));
        affinity.put(player, v);
        return v;
    }

    public void addExchange(String user, String assistant, int limit) {
        history.add(new AiClient.Msg("user", user));
        history.add(new AiClient.Msg("assistant", assistant));
        hardCap(limit);
    }

    public void addRemark(String assistant, int limit) {
        history.add(new AiClient.Msg("assistant", assistant));
        hardCap(limit);
    }

    private void hardCap(int limit) {
        while (history.size() > limit * 2) history.remove(0);
    }
}
