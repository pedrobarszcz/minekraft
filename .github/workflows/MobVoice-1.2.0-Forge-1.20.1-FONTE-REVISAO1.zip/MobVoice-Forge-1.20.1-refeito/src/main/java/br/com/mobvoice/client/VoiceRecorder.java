package br.com.mobvoice.client;

import javax.sound.sampled.*;
import java.io.ByteArrayOutputStream;

/** Captura PCM mono 16 kHz para gravações locais dos mobs. */
public class VoiceRecorder {
    public static final AudioFormat FORMAT = new AudioFormat(16000f, 16, 1, true, false);
    private volatile boolean recording;
    private volatile TargetDataLine line;
    private ByteArrayOutputStream out;
    private Thread thread;
    private volatile long startedAt;

    public boolean isRecording() { return recording; }
    public long elapsedMillis() { return startedAt == 0 ? 0 : (System.nanoTime() - startedAt) / 1_000_000L; }

    public synchronized boolean start() {
        if (recording) return false;
        try {
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, FORMAT);
            TargetDataLine opened = (TargetDataLine) AudioSystem.getLine(info);
            opened.open(FORMAT);
            opened.start();
            line = opened;
        } catch (Exception ex) {
            line = null;
            return false;
        }
        out = new ByteArrayOutputStream();
        recording = true;
        startedAt = System.nanoTime();
        thread = new Thread(() -> {
            byte[] buffer = new byte[4096];
            try {
                while (recording) {
                    TargetDataLine active = line;
                    if (active == null) break;
                    int count = active.read(buffer, 0, buffer.length);
                    if (count > 0) {
                        synchronized (out) { out.write(buffer, 0, count); }
                    }
                }
            } catch (Exception ignored) {
                // Fechar a linha durante stop() pode interromper read(); isso é esperado.
            }
        }, "MobVoice-AudioRecorder");
        thread.setDaemon(true);
        thread.start();
        return true;
    }

    public synchronized byte[] stop() {
        recording = false;
        TargetDataLine active = line;
        line = null;
        if (active != null) {
            try { active.stop(); } catch (Exception ignored) { }
            try { active.close(); } catch (Exception ignored) { }
        }
        if (thread != null) {
            try { thread.join(1500); } catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
            thread = null;
        }
        startedAt = 0;
        if (out == null) return new byte[0];
        synchronized (out) { return out.toByteArray(); }
    }
}
