package br.com.mobvoice;

import br.com.mobvoice.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> cliente: fala do mob + afinidade atual + nota opcional. */
public class ReplyPacket {
    public final int entityId;
    public final String text;
    public final int affinity;
    public final String note;

    public ReplyPacket(int entityId, String text, int affinity, String note) {
        this.entityId = entityId;
        this.text = text;
        this.affinity = affinity;
        this.note = note;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(entityId);
        buf.writeUtf(text, 1024);
        buf.writeInt(affinity);
        buf.writeUtf(note, 256);
    }

    public static ReplyPacket decode(FriendlyByteBuf buf) {
        return new ReplyPacket(buf.readInt(), buf.readUtf(1024), buf.readInt(), buf.readUtf(256));
    }

    public void handle(Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.onReply(entityId, text, affinity, note)));
        ctx.setPacketHandled(true);
    }
}
