package br.com.mobvoice;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;

/** Comunicação assíncrona com a Messages API da Anthropic. */
public final class AiClient {
    public record Msg(String role, String content) { }

    private static final Gson GSON = new Gson();
    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(12)).build();
    private static final AtomicInteger REQUESTS = new AtomicInteger();

    private AiClient() { }

    public static boolean busy() {
        return REQUESTS.get() >= AiConfig.get().maxConcurrentRequests;
    }

    public static CompletableFuture<String> chat(String system, List<Msg> messages) {
        AiConfig config = AiConfig.get();
        if (config.apiKey == null || config.apiKey.isBlank() || config.apiKey.startsWith("COLE_")) {
            return CompletableFuture.failedFuture(new IllegalStateException(
                    "Adicione sua chave Anthropic em .minecraft/config/mobvoice.json (apiKey)."));
        }
        List<Msg> normalized = normalize(messages);
        if (normalized.isEmpty()) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("A conversa está vazia."));
        }

        JsonObject body = new JsonObject();
        body.addProperty("model", config.model);
        body.addProperty("max_tokens", config.maxTokens);
        body.addProperty("system", system);
        JsonArray array = new JsonArray();
        for (Msg message : normalized) {
            JsonObject item = new JsonObject();
            item.addProperty("role", message.role());
            item.addProperty("content", message.content());
            array.add(item);
        }
        body.add("messages", array);

        final HttpRequest request;
        try {
            request = HttpRequest.newBuilder(URI.create(config.endpoint))
                    .timeout(Duration.ofSeconds(40))
                    .header("content-type", "application/json; charset=utf-8")
                    .header("x-api-key", config.apiKey)
                    .header("anthropic-version", "2023-06-01")
                    .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(body)))
                    .build();
        } catch (Exception ex) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Endpoint da IA inválido.", ex));
        }

        REQUESTS.incrementAndGet();
        return HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    if (response.statusCode() < 200 || response.statusCode() >= 300) {
                        throw new IllegalStateException("API de IA respondeu HTTP " + response.statusCode()
                                + ". Confira a chave e o modelo em mobvoice.json.");
                    }
                    JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                    JsonArray content = json.getAsJsonArray("content");
                    if (content == null || content.isEmpty()) throw new IllegalStateException("A API retornou uma resposta vazia.");
                    return content.get(0).getAsJsonObject().get("text").getAsString();
                })
                .whenComplete((result, error) -> REQUESTS.decrementAndGet());
    }

    private static List<Msg> normalize(List<Msg> input) {
        List<Msg> output = new ArrayList<>();
        if (input == null) return output;
        for (Msg message : input) {
            if (message == null || message.content() == null || message.content().isBlank()) continue;
            String role = "assistant".equals(message.role()) ? "assistant" : "user";
            if (output.isEmpty() && !role.equals("user")) continue;
            if (!output.isEmpty() && output.get(output.size() - 1).role().equals(role)) {
                Msg previous = output.remove(output.size() - 1);
                output.add(new Msg(role, previous.content() + "\n" + message.content()));
            } else {
                output.add(new Msg(role, message.content()));
            }
        }
        return output;
    }
}
