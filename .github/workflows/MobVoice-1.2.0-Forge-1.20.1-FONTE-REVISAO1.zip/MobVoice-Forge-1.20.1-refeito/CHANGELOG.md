# Changelog

## 1.1.0 — Expansão do gravador de criaturas

- Adicionado item Gravador de Voz com modelo, textura, tooltip, receita e entrada no criativo.
- Adicionada tela de estúdio para escolher categoria, gravar, salvar, ouvir e excluir.
- Adicionados sons personalizados de ambiente, dano, morte e passos.
- Arquivos WAV organizados por identificador de entidade e por adulto/filhote.
- Adicionada substituição local dos sons do jogo quando existe gravação correspondente.
- Adicionado limite de duração configurável e fallback de filhote para gravação adulta.
- Mantido o sistema anterior de conversa, memória, personalidade e afinidade.


## 1.1.1 - Expansão do estúdio
- Adicionadas categorias de gravação Ataque e Alerta.
- Ampliados os traços de personalidade, peculiaridades e objetivos dos perfis gerados para criaturas.
- Atualizada a documentação em português e inglês.


## 1.2.0 - mecânicas sociais adicionais
- Villagers podem localizar a vila mais próxima em troca de 3 esmeraldas.
- Piglins podem localizar o bastião mais próximo em troca de 5 lingotes de ouro.
- Insultos e desafios reconhecidos provocam criaturas de combate e reduzem afinidade.
- A IA recebe a categoria do item na mão do jogador (espada, arco/besta, machado ou outro) para variar a reação.
- Comunicação por voz continua no modo segurar V para falar e soltar para enviar.
